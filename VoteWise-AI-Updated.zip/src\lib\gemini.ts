import { GoogleGenerativeAI } from "@google/generative-ai";

// Ensure your .env has VITE_GEMINI_API_KEY
const apiKey = import.meta.env.VITE_GEMINI_API_KEY || "";

const genAI = new GoogleGenerativeAI(apiKey || "DUMMY_KEY");

const systemPrompt = `You are VoteWise AI.
Explain election procedures simply.
Use numbered steps.
Stay neutral.
Only voter education.
No political opinions.`;

const fallbackResponses: Record<string, string> = {
  "eligible": "To be eligible to vote, you must be a citizen and at least 18 years of age. You also need to be registered on the electoral roll.",
  "register": "To register to vote:\n1. Visit the National Voters' Services Portal (NVSP).\n2. Fill out Form 6 for new voter registration.\n3. Upload your age and address proof.\n4. Submit and track your application.",
  "id": "Valid documents include:\n- EPIC (Voter ID)\n- Aadhaar Card\n- Passport\n- Driving License\n- PAN Card",
  "where": "You can find your designated polling booth by:\n1. Using the official Electoral Search portal.\n2. Checking the Voter Helpline App.\n3. SMSing your EPIC number to the designated election number.",
  "how": "Voting Process:\n1. Officers verify your ID on the voter list.\n2. An officer inks your finger and takes your signature.\n3. Proceed to the EVM compartment.\n4. Press the blue button against your chosen candidate. A red light and beep confirm your vote.",
  "default": "I am currently in offline fallback mode. For specific questions, please refer to the official Election Commission website."
};

const getFallbackResponse = (prompt: string, language: string) => {
  const lowerPrompt = prompt.toLowerCase();
  let response = fallbackResponses["default"];
  
  if (lowerPrompt.includes("eligible") || lowerPrompt.includes("age") || lowerPrompt.includes("old") || lowerPrompt.includes("18")) {
    response = fallbackResponses["eligible"];
  } else if (lowerPrompt.includes("register") || lowerPrompt.includes("enroll") || lowerPrompt.includes("apply") || lowerPrompt.includes("form")) {
    response = fallbackResponses["register"];
  } else if (lowerPrompt.includes("id") || lowerPrompt.includes("document") || lowerPrompt.includes("proof") || lowerPrompt.includes("card") || lowerPrompt.includes("carry")) {
    response = fallbackResponses["id"];
  } else if (lowerPrompt.includes("where") || lowerPrompt.includes("booth") || lowerPrompt.includes("location") || lowerPrompt.includes("find") || lowerPrompt.includes("search")) {
    response = fallbackResponses["where"];
  } else if (lowerPrompt.includes("how") || lowerPrompt.includes("process") || lowerPrompt.includes("cast") || lowerPrompt.includes("evm") || lowerPrompt.includes("machine")) {
    response = fallbackResponses["how"];
  }

  // Simulate translation flag for offline mode
  if (language !== "English") {
     response = `[Offline Mode: Translated to ${language}]\n\n${response}`;
  }
  
  return response;
};

export const getGeminiResponse = async (prompt: string, language: string = 'English') => {
  // If no valid key is present, use fallback immediately
  if (!apiKey || apiKey === "DUMMY_KEY" || apiKey.includes("your_api_key")) {
    // Add a slight artificial delay to simulate typing/processing
    await new Promise(resolve => setTimeout(resolve, 800));
    return getFallbackResponse(prompt, language);
  }

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    
    const fullPrompt = `${systemPrompt}\n\nUser Question (Please answer in ${language}): ${prompt}`;
    
    const result = await model.generateContent(fullPrompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback on network/API errors
    return getFallbackResponse(prompt, language);
  }
};

export const analyzeEligibility = async (situation: string, language: string = 'English') => {
  if (!apiKey || apiKey === "DUMMY_KEY" || apiKey.includes("your_api_key")) {
    await new Promise(resolve => setTimeout(resolve, 800));
    // Fallback logic
    const ageMatch = situation.match(/\d+/);
    if (ageMatch && parseInt(ageMatch[0]) >= 18) {
      return { status: 'eligible', explanation: 'Based on the numbers provided, you appear to be 18 or older. Please ensure you are a citizen and registered to vote.' };
    } else if (ageMatch) {
      return { status: 'ineligible', explanation: 'You must be at least 18 years old to vote.' };
    }
    return { status: 'invalid', explanation: 'I need to know your age to determine eligibility. Please provide your age or a clear situation.' };
  }

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    const prompt = `You are an Indian Election Eligibility Analyzer. 
Analyze the following user situation and determine if they are eligible to vote in India.
Return ONLY a valid JSON object with EXACTLY two keys:
1. "status": Must be exactly "eligible", "ineligible", or "invalid".
2. "explanation": A 1-2 sentence explanation tailored to their situation in ${language}.

User Situation: "${situation}"`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text().replace(/```json/g, '').replace(/```/g, '').trim();
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini API Error (Eligibility):", error);
    return { status: 'invalid', explanation: 'Failed to analyze situation. Please enter your exact age instead.' };
  }
};
