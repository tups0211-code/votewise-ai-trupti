import React, { useState } from 'react';
import { MapPin, Search, Navigation, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Tilt from 'react-parallax-tilt';
import { useLanguage } from '../contexts/LanguageContext';

const mockBooths = [
  { id: 1, name: 'St. Mary High School', address: '123 Education Rd, City Center', distance: '0.8 km', type: 'Primary' },
  { id: 2, name: 'Community Hall Block B', address: '45 Residential Ave, South Wing', distance: '1.2 km', type: 'Secondary' },
  { id: 3, name: 'City Municipal Office', address: '88 Admin Circle, Downtown', distance: '2.5 km', type: 'Secondary' },
];

const PollingBooth = () => {
  const [pinCode, setPinCode] = useState('');
  const [searched, setSearched] = useState(false);
  const { t } = useLanguage();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinCode.length >= 4) {
      setSearched(true);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 relative overflow-hidden pt-32 pb-24">
      {/* Premium Background Mesh */}
      <div className="absolute inset-0 pointer-events-none -z-10">
        <div className="absolute top-[0%] left-[-10%] w-[60%] h-[60%] bg-blue-electric/10 rounded-full mix-blend-multiply filter blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-500/10 rounded-full mix-blend-multiply filter blur-[120px]"></div>
      </div>

      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
            className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white shadow-sm border border-slate-100 text-blue-electric mb-6"
          >
            <MapPin size={32} />
          </motion.div>
          <motion.h1 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-black text-slate-900 mb-6 tracking-tight"
          >
            {t('polling', 'title')}
          </motion.h1>
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-slate-500 text-xl max-w-2xl mx-auto font-normal"
          >
            {t('polling', 'desc')}
          </motion.p>
        </div>

        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-white p-8 md:p-10 rounded-[2rem] shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-slate-100"
        >
          <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4 mb-12">
            <div className="flex-grow relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-electric to-cyan-bright rounded-2xl blur opacity-20 group-focus-within:opacity-40 transition duration-500"></div>
              <div className="relative">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={24} />
                <input
                  type="text"
                  placeholder={t('polling', 'placeholder')}
                  value={pinCode}
                  onChange={(e) => setPinCode(e.target.value)}
                  className="w-full pl-16 pr-6 py-5 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-electric focus:border-transparent text-xl font-medium transition-all"
                  aria-label="PIN Code"
                />
              </div>
            </div>
            <button
              type="submit"
              className="px-10 py-5 bg-slate-900 text-white rounded-2xl font-bold text-lg hover:bg-blue-electric transition-colors flex items-center justify-center gap-2 flex-shrink-0"
            >
              {t('polling', 'btn')}
            </button>
          </form>

          <AnimatePresence>
            {searched ? (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-lg font-bold text-slate-800 flex items-center gap-3">
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
                    </span>
                    {t('polling', 'results')} <span className="px-2 py-1 bg-slate-100 rounded text-slate-900">{pinCode}</span>
                  </h3>
                </div>
                
                <div className="grid gap-4">
                  {mockBooths.map((booth, idx) => (
                    <motion.div 
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      key={booth.id} 
                    >
                      <Tilt tiltMaxAngleX={2} tiltMaxAngleY={2} perspective={1000} scale={1.01} transitionSpeed={2000} gyroscope={true}>
                        <div className="group flex flex-col md:flex-row md:items-center justify-between p-6 bg-white rounded-2xl border border-slate-100 hover:border-blue-electric/30 transition-all duration-300 gap-6 shadow-sm hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] cursor-pointer">
                          <div>
                            <div className="flex items-center gap-3 mb-2">
                              <h4 className="font-extrabold text-slate-900 text-xl">{booth.name}</h4>
                              <span className={`text-[10px] uppercase tracking-widest font-bold px-2 py-1 rounded-sm ${booth.type === 'Primary' ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-600'}`}>
                                {booth.type}
                              </span>
                            </div>
                            <p className="text-slate-500 flex items-center gap-2 text-base">
                              <MapPin size={16} className="text-slate-400" /> {booth.address}
                            </p>
                          </div>
                          <div className="flex items-center gap-6 md:border-l md:border-slate-100 md:pl-6">
                            <div className="flex flex-col items-end">
                              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">{t('polling', 'distance')}</span>
                              <span className="text-xl font-black text-slate-800">
                                {booth.distance}
                              </span>
                            </div>
                            <button className="p-3 bg-slate-50 border border-slate-200 rounded-xl hover:bg-slate-900 hover:text-white hover:border-slate-900 transition-colors text-slate-600" aria-label="Get Directions">
                              <Navigation size={20} />
                            </button>
                          </div>
                        </div>
                      </Tilt>
                    </motion.div>
                  ))}
                </div>
                
                <div className="mt-8 p-4 bg-slate-50 rounded-2xl border border-slate-100 text-slate-500 text-sm flex gap-3 items-start">
                  <Info className="flex-shrink-0 text-slate-400 mt-0.5" size={18} />
                  <p>{t('polling', 'mock')}</p>
                </div>
              </motion.div>
            ) : (
              <div className="text-center py-16 text-slate-400">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-50 border border-slate-100 mb-6">
                  <Search className="w-8 h-8 text-slate-300" />
                </div>
                <p className="text-lg font-medium">{t('polling', 'enter')}</p>
              </div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
};

export default PollingBooth;
