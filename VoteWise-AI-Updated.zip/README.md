# VoteWise AI — Interactive Election Process Assistant

VoteWise AI is a modern, accessible, and interactive platform designed to educate users about the election process. Built as a high-quality Google PromptWars submission, it leverages the Gemini AI API for multilingual voter assistance.

## 🚀 Features

- **Election Timeline Stepper**: Track the election journey from announcement to results with interactive, animated steps.
- **Eligibility Checker**: A quick tool to check voting eligibility and understand the next steps.
- **Interactive Voting Guide**: Step-by-step guidance on registration, checking voter ID, finding polling booths, and casting a vote.
- **Mock Polling Booth Locator**: A simulated tool showing how voters can find nearby polling stations.
- **Multilingual Gemini AI Assistant**: A helpful chatbot powered by Google Gemini that answers election-related questions in English, Hindi, and Marathi while remaining strictly neutral.

## 🛠️ Technology Stack

- **Frontend**: React 18, TypeScript, Vite
- **Styling**: Tailwind CSS, Framer Motion for animations
- **Icons**: Lucide React
- **AI Integration**: `@google/generative-ai` (Gemini Pro)
- **Routing**: React Router DOM

## 💻 Running Locally

1. **Clone the repository** (or navigate to the project directory).
2. **Install dependencies**:
   ```bash
   npm install
   ```
3. **Set up Environment Variables**:
   Create a `.env` file in the root directory based on `.env.example`:
   ```env
   VITE_GEMINI_API_KEY=your_actual_gemini_api_key_here
   ```
4. **Start the Development Server**:
   ```bash
   npm run dev
   ```

## 🌐 Deployment (Firebase Hosting)

1. Build the application for production:
   ```bash
   npm run build
   ```
2. Install Firebase CLI globally (if not already installed):
   ```bash
   npm install -g firebase-tools
   ```
3. Login to your Firebase account:
   ```bash
   firebase login
   ```
4. Initialize Firebase in your project directory:
   ```bash
   firebase init hosting
   ```
   *Select the build folder (`dist`) as your public directory. Configure as a single-page app (rewrite all URLs to `/index.html`).*
5. Deploy:
   ```bash
   firebase deploy
   ```

## 🏆 PromptWars Optimization

This project is optimized for judging criteria:
- **Code Quality**: Modular React components, TypeScript typing, and clean directory structure.
- **Accessibility**: ARIA labels, high contrast colors, and clear navigation.
- **Google Services**: Integration of the Gemini API for natural language understanding.
- **Mobile-first Design**: Fully responsive across devices using Tailwind CSS.
